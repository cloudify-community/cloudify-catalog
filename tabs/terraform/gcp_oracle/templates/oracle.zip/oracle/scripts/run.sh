#!/bin/bash

sudo apt-get install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo apt-key fingerprint 0EBFCD88
sudo add-apt-repository \
   "deb [arch=amd64] https://download.docker.com/linux/ubuntu \
   $(lsb_release -cs) \
   stable"
sudo apt-get update
sudo apt-get install -y docker-ce
# Linux post-install
sudo groupadd docker
sudo usermod -aG docker ${username}
sudo systemctl enable docker
sudo docker run -d -p 1521:1521 -e ORACLE_PASSWORD=${system_pwd} -e ORACLE_DATABASE=${database_name} -e APP_USER=${username} -e APP_USER_PASSWORD=${username_pwd} gvenzl/oracle-xe:21-slim