#!/bin/bash


# Save SSH public key
echo "$PUBLIC_KEY" > ~/.ssh/authorized_keys

# Disable SSH password authentication
sudo sed -i 's/PasswordAuthentication  yes/PasswordAuthentication  no/g' /etc/ssh/sshd_config
sudo service sshd restart
