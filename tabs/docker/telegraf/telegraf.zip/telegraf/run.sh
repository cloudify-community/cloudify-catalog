#!/bin/bash -e

sleep 10
telegraf