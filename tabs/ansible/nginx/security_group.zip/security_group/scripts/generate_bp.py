import zipfile
from string import ascii_lowercase

from cloudify import ctx
from cloudify.state import ctx_parameters as inputs
from cloudify.utils import id_generator
from jinja2 import Environment, FileSystemLoader

ctx.instance.runtime_properties['value'] =  id_ = id_generator(size=6, chars=ascii_lowercase)

ports = [ port.lower() for port in inputs["ports"] ]
provider = inputs["provider"]

rules = [ {"from_port" : port, "to_port" : port } for port in ports ]

environment = Environment(loader=FileSystemLoader("templates/"))

results_filename = "{}.yaml".format(provider)
results_template = environment.get_template(results_filename)


context = {
    "rules": rules
}

with open(results_filename, mode="w", encoding="utf-8") as results:
    results.write(results_template.render(context))

with zipfile.ZipFile(f"/tmp/{id_}/sg.zip", mode="w") as archive:
    archive.write(results_filename)
