#!/bin/bash


# Download and prepare longhorn_install kubernetes manifest
longhorn_install=$(ctx download_resource scripts/sources/longhorn_install.yaml)
cp $longhorn_install ./longhorn_install.yaml
chmod 744 ./longhorn_install.yaml

# Apply Longhorn installation and wait for all necessary pods to get ready
kubectl apply -f longhorn_install.yaml
kubectl wait --for=condition=Ready pod --all -n longhorn-system --timeout=600s

# Expose Longhorn UI
sudo apt update
sudo apt install -y nginx
sudo rm -f default
frontend_ip=$(kubectl -n longhorn-system get svc longhorn-frontend -o jsonpath='{.spec.clusterIP}')
echo """
server {
  listen *:${PORT};
  location / {
    proxy_pass http://${frontend_ip};
  }
}
""" | sudo tee /etc/nginx/sites-enabled/longhorn
sudo service nginx restart

# Clean-up
rm -f ./longhorn_install.yaml
