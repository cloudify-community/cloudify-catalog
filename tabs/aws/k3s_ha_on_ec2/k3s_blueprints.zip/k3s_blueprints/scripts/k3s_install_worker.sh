#!/bin/bash


# Download and prepare k3s_install script
k3s_install=$(ctx download_resource scripts/sources/k3s_install.sh)
cp $k3s_install ./k3s_install.sh
chmod 744 ./k3s_install.sh

# WORKER NODES ONLY - install K3S as agent
export K3S_TOKEN=$TOKEN
export K3S_URL="https://$MASTER_IP:6443"
./k3s_install.sh

# Clean-up
rm -f $k3s_install ./k3s_install.sh
