#!/bin/bash


# Download and prepare k3s_install script
k3s_install=$(ctx download_resource scripts/sources/k3s_install.sh)
cp $k3s_install ./k3s_install.sh
chmod 744 ./k3s_install.sh

# ADDITIONAL MASTER NODES ONLY - create additional master node
export INSTALL_K3S_EXEC="--write-kubeconfig-mode 644 --node-taint k3s-controlplane=true:NoExecute"
export K3S_TOKEN=$TOKEN
./k3s_install.sh server --server https://${MASTER_IP}:6443

# Clean-up
rm -f $k3s_install ./k3s_install.sh
