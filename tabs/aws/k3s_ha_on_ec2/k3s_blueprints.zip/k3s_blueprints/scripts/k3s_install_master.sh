#!/bin/bash


# Generate K3S cluster token
TOKEN=ece-kubernetes-$(cat /proc/sys/kernel/random/uuid)

# Download and prepare k3s_install script
k3s_install=$(ctx download_resource scripts/sources/k3s_install.sh)
cp $k3s_install ./k3s_install.sh
chmod 744 ./k3s_install.sh

# FIRST MASTER NODE ONLY - create master node
export INSTALL_K3S_EXEC="--write-kubeconfig-mode 644 --node-taint k3s-controlplane=true:NoExecute"
export K3S_TOKEN=$TOKEN
./k3s_install.sh server --cluster-init

# Save K3S token and kubeconfig
ctx instance runtime-properties "token" "${TOKEN}"
kubeconfig=$(sudo cat /etc/rancher/k3s/k3s.yaml)
ctx instance runtime-properties "kubeconfig" "${kubeconfig}"

# Clean-up
rm -f $k3s_install ./k3s_install.sh
